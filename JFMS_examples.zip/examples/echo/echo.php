<?php
echo $_REQUEST["message"];

/* 
 * The code for the Lorem Ipsum exercise. This is where your solution goes.
 * 
 * Sam Scott, June 2012.
 */



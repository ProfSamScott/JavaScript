/* 
 * AJAX Exercise: More!
 * 
 * *** SOLUTION ***
 * 
 * Your code goes here.
 * 
 * Sam Scott, June 2012
 */



/* 
 * Very simple function demonstration.
 * 
 * Sam Scott, February 2017
 */

/**
 * Say hello.
 * @returns {undefined}
 */
function hello() {
    alert("Hello, world!");
}